| name | ALIGNN-JARVIS Formation Energy [eV/atom] | ALIGNN-JARVIS MBJ Bandgap [eV] | ALIGNN-JARVIS Shear Modulus [GPa] | ALIGNN-JARVIS Bulk Modulus [GPa] | ALIGNN-JARVIS Exfoliation Energy [meV/atom] | ALIGNN-MP Formation Energy [eV/atom] | ALIGNN-MP PBE Bandgap [eV] |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Y2Fe14B.POSCAR | -0.0765 | -0.0093 | 33.8686 | 138.7862 | 388.8384 | -0.1065 | 0.0023 |
| Y3FeB7.POSCAR | 0.5488 | 0.0115 | 59.5372 | 83.8282 | 90.2057 | 0.5076 | 0.0626 |
| Y5Fe2B6.POSCAR | 0.6176 | 0.0151 | 55.6916 | 66.9949 | 194.966 | 0.0441 | 0.0183 |
| YFe2B2.POSCAR | 0.2469 | -0.0061 | 47.018 | 94.8629 | 164.788 | 0.076 | 0.0049 |
| YFe4B4.POSCAR | -0.5113 | -0.0339 | 98.2523 | 189.7609 | 150.9346 | -0.4951 | 0.0021 |
| YFeB4.POSCAR | -0.6369 | 0.1306 | 171.5543 | 209.9274 | 80.1751 | -0.5498 | -0.0122 |
