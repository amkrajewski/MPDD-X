
Please note that these are *energies*, not *formation energies*.
| Name | CHGNet_0.3.0-MP Energy [eV/atom] | CHGNet_0.3.0-MP Relaxed Energy [eV/atom] |
| --- | --- | --- |
| Y2Fe14B.POSCAR | -8.1995 | -8.2 |
| Y3FeB7.POSCAR | -5.5448 | -6.075 |
| Y5Fe2B6.POSCAR | -5.3717 | -5.6999 |
| YFe2B2.POSCAR | -7.1529 | -7.3328 |
| YFe4B4.POSCAR | -7.9125 | -7.9158 |
| YFeB4.POSCAR | -7.7017 | -7.7523 |
