Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| Y2Fe14B.POSCAR | Y8 Fe56 B4 | tetragonal | P4_2/mnm | 13.534 |
| Y3FeB7.POSCAR | Y6 Fe2 B14 | orthorhombic | Pmma | 22.690 |
| Y5Fe2B6.POSCAR | Y5 Fe2 B6 | hexagonal | P6/mmm | 45.659 |
| YFe2B2.POSCAR | Y1 Fe4 B2 | tetragonal | P4/mmm | 17.164 |
| YFe4B4.POSCAR | Y16 Fe56 B56 | orthorhombic | Pccn | 10.615 |
| YFeB4.POSCAR | Y4 Cr4 B16 | orthorhombic | Pbam | 9.869 |
