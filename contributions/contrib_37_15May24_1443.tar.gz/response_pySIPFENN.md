| name | SIPFENN_NN30-OQMD [eV/atom] |
| --- | --- |
| Sm2Fe14B.POSCAR | -0.0568 |
| Sm5Fe2B6.POSCAR | 0.3408 |
| SmFe4B4.POSCAR | -0.3881 |
| SmFeB4.POSCAR | -0.4936 |
