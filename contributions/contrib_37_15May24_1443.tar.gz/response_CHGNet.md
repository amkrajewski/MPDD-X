
Please note that these are *energies*, not *formation energies*.
| Name | CHGNet_0.3.0-MP Energy [eV/atom] | CHGNet_0.3.0-MP Relaxed Energy [eV/atom] |
| --- | --- | --- |
| Sm2Fe14B.POSCAR | -7.9626 | -7.9632 |
| Sm5Fe2B6.POSCAR | -4.928 | -5.2824 |
| SmFe4B4.POSCAR | -7.5239 | -7.6733 |
| SmFeB4.POSCAR | -7.1706 | -7.1914 |
