Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| Sm2Fe14B.POSCAR | Sm8 Fe56 B4 | tetragonal | P4_2/mnm | 13.811 |
| Sm5Fe2B6.POSCAR | Sm4 Fe3 B6 | hexagonal | P6/mmm | 47.011 |
| SmFe4B4.POSCAR | Sm34 Fe120 B120 | tetragonal | P4_2/n | 10.792 |
| SmFeB4.POSCAR | Sm4 Fe4 B16 | orthorhombic | Pbam | 9.918 |
