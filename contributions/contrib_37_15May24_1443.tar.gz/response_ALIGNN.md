| name | ALIGNN-JARVIS Formation Energy [eV/atom] | ALIGNN-JARVIS MBJ Bandgap [eV] | ALIGNN-JARVIS Shear Modulus [GPa] | ALIGNN-JARVIS Bulk Modulus [GPa] | ALIGNN-JARVIS Exfoliation Energy [meV/atom] | ALIGNN-MP Formation Energy [eV/atom] | ALIGNN-MP PBE Bandgap [eV] |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Sm2Fe14B.POSCAR | -0.0366 | -0.0345 | 29.6276 | 129.9217 | 383.9913 | -0.0738 | 0.0088 |
| Sm5Fe2B6.POSCAR | 0.7372 | 0.0003 | 46.7717 | 63.3542 | 154.6127 | 0.1532 | 0.016 |
| SmFe4B4.POSCAR | -0.3926 | -0.0016 | 85.6641 | 175.8087 | 139.6198 | -0.4272 | 0.0124 |
| SmFeB4.POSCAR | -0.5379 | 0.0424 | 165.34 | 201.7846 | 44.0713 | -0.545 | 0.0009 |
