| name | ALIGNN-JARVIS Formation Energy [eV/atom] | ALIGNN-JARVIS MBJ Bandgap [eV] | ALIGNN-JARVIS Shear Modulus [GPa] | ALIGNN-JARVIS Bulk Modulus [GPa] | ALIGNN-JARVIS Exfoliation Energy [meV/atom] | ALIGNN-MP Formation Energy [eV/atom] | ALIGNN-MP PBE Bandgap [eV] |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Ce3Rh2.POSCAR | -0.6896 | -0.0304 | 21.1214 | 78.9481 | 438.9398 | -0.6388 | 0.0116 |
| Ce7Rh3.POSCAR | -0.5686 | -0.0541 | 22.6941 | 61.0827 | 421.6457 | -0.4776 | 0.0064 |
| Ce.POSCAR | -0.002 | 0.0199 | 25.6281 | 36.7025 | 398.2325 | 0.0869 | 0.0143 |
| CeRh2.POSCAR | -0.7464 | -0.0023 | 51.9232 | 154.9653 | 454.6729 | -0.7146 | 0.0063 |
| CeRh3.POSCAR | -0.6446 | -0.0039 | 66.7432 | 163.6737 | 428.2826 | -0.6458 | 0.0044 |
| CeRh.POSCAR | -0.8068 | -0.0487 | 29.6937 | 101.3445 | 424.5614 | -0.7628 | 0.0004 |
| Rh.POSCAR | -0.0055 | -0.0061 | 155.7439 | 257.8409 | 375.0273 | -0.0012 | 0.0089 |
