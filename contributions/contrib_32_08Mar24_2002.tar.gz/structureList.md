Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| Ce3Rh2.POSCAR | Ce27 Rh18 | trigonal | R-3 | 24.259 |
| Ce7Rh3.POSCAR | Ce14 Rh6 | hexagonal | P6_3mc | 25.768 |
| Ce.POSCAR | Ce4 | cubic | Fm-3m | 31.131 |
| CeRh2.POSCAR | Ce8 Rh16 | cubic | Fd-3m | 18.057 |
| CeRh3.POSCAR | Ce1 Rh3 | cubic | Pm-3m | 16.969 |
| CeRh.POSCAR | Ce4 Rh4 | orthorhombic | Cmcm | 22.253 |
| Rh.POSCAR | Rh4 | cubic | Fm-3m | 14.485 |
