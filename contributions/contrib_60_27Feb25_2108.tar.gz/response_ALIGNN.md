| name | ALIGNN-JARVIS Formation Energy [eV/atom] | ALIGNN-JARVIS MBJ Bandgap [eV] | ALIGNN-JARVIS Shear Modulus [GPa] | ALIGNN-JARVIS Bulk Modulus [GPa] | ALIGNN-JARVIS Exfoliation Energy [meV/atom] | ALIGNN-MP Formation Energy [eV/atom] | ALIGNN-MP PBE Bandgap [eV] |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Er3Ga5.POSCAR | -0.6174 | 0.003 | 39.4879 | 72.3048 | 278.9927 | -0.6188 | -0.006 |
| Er5Ga3.POSCAR | -0.4962 | -0.0185 | 33.6172 | 52.8528 | 346.9632 | -0.4845 | -0.0019 |
| ErGa2.POSCAR | -0.6114 | 0.0424 | 56.9106 | 82.3333 | 185.0578 | -0.6013 | -0.0024 |
| ErGa3.POSCAR | -0.5112 | 0.0003 | 36.5299 | 69.7266 | 255.9279 | -0.5179 | -0.0067 |
| ErGa6.POSCAR | -0.2873 | 0.0071 | 42.1973 | 76.6841 | 189.9411 | -0.3146 | 0.0096 |
| ErGa.POSCAR | -0.6279 | -0.0178 | 47.2361 | 72.5413 | 205.9584 | -0.6219 | -0.0102 |
