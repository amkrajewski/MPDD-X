| name | SIPFENN_NN30-OQMD [eV/atom] |
| --- | --- |
| Er3Ga5.POSCAR | -0.6423 |
| Er5Ga3.POSCAR | -0.4825 |
| ErGa2.POSCAR | -0.6084 |
| ErGa3.POSCAR | -0.5132 |
| ErGa6.POSCAR | -0.3089 |
| ErGa.POSCAR | -0.5615 |
