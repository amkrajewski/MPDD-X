Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| Er3Ga5.POSCAR | Er12 Ga20 | orthorhombic | Pnma | 20.289 |
| Er5Ga3.POSCAR | Er10 Ga6 | hexagonal | P6_3/mcm | 25.167 |
| ErGa2.POSCAR | Er1 Ga2 | hexagonal | P6/mmm | 20.165 |
| ErGa3.POSCAR | Er1 Ga3 | cubic | Pm-3m | 18.679 |
| ErGa6.POSCAR | Er2 Ga12 | tetragonal | P4/nbm | 18.514 |
| ErGa.POSCAR | Er4 Ga4 | orthorhombic | Cmcm | 22.896 |
