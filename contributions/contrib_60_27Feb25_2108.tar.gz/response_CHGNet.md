
Please note that these are *energies*, not *formation energies*.
| Name | CHGNet_0.3.0-MP Energy [eV/atom] | CHGNet_0.3.0-MP Relaxed Energy [eV/atom] |
| --- | --- | --- |
| Er3Ga5.POSCAR | -4.2308 | -4.2361 |
| Er5Ga3.POSCAR | -4.4849 | -4.4849 |
| ErGa2.POSCAR | -4.1471 | -4.1557 |
| ErGa3.POSCAR | -3.9344 | -3.9344 |
| ErGa6.POSCAR | -3.5424 | -3.5462 |
| ErGa.POSCAR | -4.4208 | -4.4227 |
