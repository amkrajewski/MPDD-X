| name | SIPFENN_NN30-OQMD [eV/atom] |
| --- | --- |
| Co2Zr.vasp | 0.3413 |
| Co23Zr6.vasp | 0.2677 |
| CoZr2.vasp | -0.0802 |
| CoZr3.vasp | 0.3218 |
| CoZr.vasp | -0.2802 |
