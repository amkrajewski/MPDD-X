| name | ALIGNN-JARVIS Formation Energy [eV/atom] | ALIGNN-JARVIS MBJ Bandgap [eV] | ALIGNN-JARVIS Shear Modulus [GPa] | ALIGNN-JARVIS Bulk Modulus [GPa] | ALIGNN-JARVIS Exfoliation Energy [meV/atom] | ALIGNN-MP Formation Energy [eV/atom] | ALIGNN-MP PBE Bandgap [eV] |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Co2Zr.vasp | 2.0991 | -0.0354 | 33.2231 | 142.587 | 358.2221 | 0.9045 | -0.0014 |
| Co23Zr6.vasp | 0.94 | -0.0248 | 13.9053 | 140.2311 | 337.5581 | 0.6181 | 0.0063 |
| CoZr2.vasp | -0.2281 | 0.1144 | 31.1619 | 106.3424 | 454.0326 | -0.204 | -0.0004 |
| CoZr3.vasp | 1.029 | -0.0304 | 11.3437 | 100.1977 | 446.1699 | 0.7778 | -0.0157 |
| CoZr.vasp | -0.3485 | -0.0316 | 35.8935 | 153.6863 | 398.4953 | -0.2923 | 0.0077 |
