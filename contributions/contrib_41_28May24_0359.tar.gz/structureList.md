Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| Co2Zr.vasp | Zr2 Co7 | trigonal | R-3m | 37.300 |
| Co23Zr6.vasp | Zr6 Co29 | cubic | Pm-3m | 43.567 |
| CoZr2.vasp | Zr8 Co2 | tetragonal | P4/mcc | 22.143 |
| CoZr3.vasp | Zr6 Co2 | orthorhombic | Pmma | 39.656 |
| CoZr.vasp | Zr1 Co1 | cubic | Pm-3m | 16.292 |
