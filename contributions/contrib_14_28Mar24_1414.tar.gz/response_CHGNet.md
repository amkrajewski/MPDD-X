
Please note that these are *energies*, not *formation energies*.
| Name | CHGNet_0.3.0-MP Energy [eV/atom] | CHGNet_0.3.0-MP Relaxed Energy [eV/atom] |
| --- | --- | --- |
| POS0.POSCAR | -4.0776 | -4.0776 |
| POS1.POSCAR | -3.3088 | -3.316 |
| POS2.POSCAR | -4.7676 | -4.7685 |
| POS3.POSCAR | -3.7095 | -3.7162 |
| POS4.POSCAR | -2.8984 | -2.9024 |
| POS5.POSCAR | -4.6725 | -4.6748 |
| POS6.POSCAR | -4.4572 | -4.4572 |
| POS7.POSCAR | -3.8661 | -3.8793 |
| POS8.POSCAR | -4.9868 | -4.9979 |
| POS9.POSCAR | -3.7095 | -3.7162 |
| POS10.POSCAR | -2.8984 | -2.9024 |
| POS11.POSCAR | -4.6725 | -4.6748 |
| POS12.POSCAR | -3.3088 | -3.316 |
| POS13.POSCAR | -2.6875 | -2.698 |
| POS14.POSCAR | -4.3941 | -4.4111 |
| POS15.POSCAR | -4.2112 | -4.2233 |
| POS16.POSCAR | -3.4649 | -3.4649 |
| POS17.POSCAR | -5.006 | -5.006 |
| POS18.POSCAR | -4.4572 | -4.4572 |
| POS19.POSCAR | -3.8661 | -3.8793 |
| POS20.POSCAR | -4.9868 | -4.9979 |
| POS21.POSCAR | -4.2112 | -4.2233 |
| POS22.POSCAR | -3.4649 | -3.4649 |
| POS23.POSCAR | -5.006 | -5.006 |
| POS24.POSCAR | -4.7676 | -4.7685 |
| POS25.POSCAR | -4.3941 | -4.4111 |
| POS26.POSCAR | -5.1773 | -5.1973 |
