Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| POS0.POSCAR | Cu8 | tetragonal | I4/mmm | 11.830 |
| POS1.POSCAR | In4 Cu4 | tetragonal | P4/mmm | 18.249 |
| POS2.POSCAR | Cu4 Pd4 | tetragonal | P4/mmm | 13.476 |
| POS3.POSCAR | In2 Cu6 | tetragonal | I4/mmm | 14.888 |
| POS4.POSCAR | In6 Cu2 | tetragonal | I4/mmm | 21.961 |
| POS5.POSCAR | In2 Cu2 Pd4 | tetragonal | I4/mmm | 16.129 |
| POS6.POSCAR | Cu6 Pd2 | tetragonal | I4/mmm | 12.719 |
| POS7.POSCAR | In4 Cu2 Pd2 | tetragonal | I4/mmm | 18.659 |
| POS8.POSCAR | Cu2 Pd6 | tetragonal | I4/mmm | 14.129 |
| POS9.POSCAR | In2 Cu6 | tetragonal | I4/mmm | 14.888 |
| POS10.POSCAR | In6 Cu2 | tetragonal | I4/mmm | 21.961 |
| POS11.POSCAR | In2 Cu2 Pd4 | tetragonal | I4/mmm | 16.129 |
| POS12.POSCAR | In4 Cu4 | tetragonal | P4/mmm | 18.249 |
| POS13.POSCAR | In8 | tetragonal | I4/mmm | 26.082 |
| POS14.POSCAR | In4 Pd4 | tetragonal | P4/mmm | 19.002 |
| POS15.POSCAR | In2 Cu4 Pd2 | tetragonal | I4/mmm | 15.560 |
| POS16.POSCAR | In6 Pd2 | tetragonal | I4/mmm | 22.051 |
| POS17.POSCAR | In2 Pd6 | tetragonal | I4/mmm | 16.616 |
| POS18.POSCAR | Cu6 Pd2 | tetragonal | I4/mmm | 12.719 |
| POS19.POSCAR | In4 Cu2 Pd2 | tetragonal | I4/mmm | 18.659 |
| POS20.POSCAR | Cu2 Pd6 | tetragonal | I4/mmm | 14.129 |
| POS21.POSCAR | In2 Cu4 Pd2 | tetragonal | I4/mmm | 15.560 |
| POS22.POSCAR | In6 Pd2 | tetragonal | I4/mmm | 22.051 |
| POS23.POSCAR | In2 Pd6 | tetragonal | I4/mmm | 16.616 |
| POS24.POSCAR | Cu4 Pd4 | tetragonal | P4/mmm | 13.476 |
| POS25.POSCAR | In4 Pd4 | tetragonal | P4/mmm | 19.002 |
| POS26.POSCAR | Pd8 | tetragonal | I4/mmm | 14.698 |
