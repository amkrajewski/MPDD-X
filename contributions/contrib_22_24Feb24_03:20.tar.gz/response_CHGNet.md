
Please note that these are *energies*, not *formation energies*.
| Name | CHGNet_0.3.0-MP Energy [eV/atom] | CHGNet_0.3.0-MP Relaxed Energy [eV/atom] |
| --- | --- | --- |
| POS1.POSCAR | -4.8025 | -6.4985 |
| POS2.POSCAR | -4.7989 | -6.4752 |
| POS3.POSCAR | -4.7968 | -6.4717 |
| POS4.POSCAR | -4.8027 | -6.5373 |
| POS5.POSCAR | -4.8017 | -6.4655 |
| POS6.POSCAR | -4.8398 | -6.4744 |
| POS7.POSCAR | -4.8039 | -6.487 |
| POS8.POSCAR | -4.8002 | -6.4897 |
| POS9.POSCAR | -4.8406 | -6.5061 |
| POS10.POSCAR | -4.8026 | -6.4983 |
| POS11.POSCAR | -4.803 | -6.5373 |
| POS12.POSCAR | -4.8405 | -6.5062 |
| POS13.POSCAR | -4.8366 | -6.4595 |
| POS14.POSCAR | -4.8398 | -6.4743 |
| POS15.POSCAR | -4.879 | -6.5094 |
| POS16.POSCAR | -4.8393 | -6.4742 |
