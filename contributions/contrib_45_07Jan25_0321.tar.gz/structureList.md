Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| CoCo.POSCAR | Co4 | cubic | Fm-3m | 10.996 |
| CoPt.POSCAR | Co1 Pt3 | cubic | Pm-3m | 14.822 |
| CoSc.POSCAR | Sc3 Co1 | cubic | Pm-3m | 18.024 |
| PtCo.POSCAR | Co3 Pt1 | cubic | Pm-3m | 12.922 |
| PtPt.POSCAR | Pt4 | cubic | Fm-3m | 15.360 |
| PtSc.POSCAR | Sc3 Pt1 | cubic | Pm-3m | 18.236 |
| ScCo.POSCAR | Sc1 Co3 | cubic | Pm-3m | 12.405 |
| ScPt.POSCAR | Sc1 Pt3 | cubic | Pm-3m | 15.795 |
| ScSc.POSCAR | Sc4 | cubic | Fm-3m | 25.009 |
