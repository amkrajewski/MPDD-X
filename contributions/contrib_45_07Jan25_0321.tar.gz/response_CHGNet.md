
Please note that these are *energies*, not *formation energies*.
| Name | CHGNet_0.3.0-MP Energy [eV/atom] | CHGNet_0.3.0-MP Relaxed Energy [eV/atom] |
| --- | --- | --- |
| CoCo.POSCAR | -7.0261 | -7.0261 |
| CoPt.POSCAR | -6.3574 | -6.3585 |
| CoSc.POSCAR | -6.4963 | -6.516 |
| PtCo.POSCAR | -6.7884 | -6.8116 |
| PtPt.POSCAR | -6.0867 | -6.0923 |
| PtSc.POSCAR | -6.8606 | -6.9134 |
| ScCo.POSCAR | -7.0316 | -7.0349 |
| ScPt.POSCAR | -7.1511 | -7.1586 |
| ScSc.POSCAR | -6.2732 | -6.2732 |
