| name | SIPFENN_NN30-OQMD [eV/atom] |
| --- | --- |
| CoCo.POSCAR | 0.0947 |
| CoPt.POSCAR | -0.0558 |
| CoSc.POSCAR | 0.0828 |
| PtCo.POSCAR | -0.0274 |
| PtPt.POSCAR | 0.0033 |
| PtSc.POSCAR | -0.4913 |
| ScCo.POSCAR | -0.055 |
| ScPt.POSCAR | -0.9368 |
| ScSc.POSCAR | 0.062 |
