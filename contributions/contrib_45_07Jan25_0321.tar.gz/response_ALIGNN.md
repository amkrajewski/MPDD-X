| name | ALIGNN-JARVIS Formation Energy [eV/atom] | ALIGNN-JARVIS MBJ Bandgap [eV] | ALIGNN-JARVIS Shear Modulus [GPa] | ALIGNN-JARVIS Bulk Modulus [GPa] | ALIGNN-JARVIS Exfoliation Energy [meV/atom] | ALIGNN-MP Formation Energy [eV/atom] | ALIGNN-MP PBE Bandgap [eV] |
| --- | --- | --- | --- | --- | --- | --- | --- |
| CoCo.POSCAR | -0.0001 | 0.0151 | 117.3782 | 210.4772 | 331.9581 | 0.0093 | 0.015 |
| CoPt.POSCAR | -0.0464 | 0.0188 | 83.5758 | 233.3471 | 407.4589 | 0.0514 | 0.0121 |
| CoSc.POSCAR | -0.0075 | -0.012 | 8.9837 | 82.5938 | 440.3416 | 0.0294 | -0.0043 |
| PtCo.POSCAR | -0.0041 | 0.0125 | 113.7445 | 217.9588 | 361.1328 | -0.0411 | -0.0016 |
| PtPt.POSCAR | -0.0021 | -0.0139 | 56.4635 | 251.9593 | 442.6022 | -0.0075 | 0.0052 |
| PtSc.POSCAR | -0.5505 | -0.0265 | 1.5312 | 93.4334 | 478.57 | -0.6277 | 0.005 |
| ScCo.POSCAR | -0.1495 | -0.0098 | 81.7151 | 156.2864 | 357.6409 | -0.1279 | -0.0006 |
| ScPt.POSCAR | -1.0809 | -0.0277 | 94.9403 | 205.2485 | 443.2433 | -1.0543 | 0.0086 |
| ScSc.POSCAR | 0.0567 | -0.0149 | 26.9171 | 51.9979 | 499.002 | 0.0445 | 0.0015 |
