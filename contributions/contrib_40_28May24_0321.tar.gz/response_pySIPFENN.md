| name | SIPFENN_NN30-OQMD [eV/atom] |
| --- | --- |
| Co2Zr.vasp | 0.3413 |
| Co23Zr6.vasp | 0.2677 |
| Co (2).vasp | 0.0934 |
| Co.vasp | 0.4451 |
| CoZr2.vasp | -0.0802 |
| CoZr3.vasp | 0.3218 |
| CoZr.vasp | -0.2802 |
| Y2Co7.vasp | 0.0439 |
| Y2Co17 (2).vasp | 0.0553 |
| Y2Co17.vasp | 0.0971 |
| Y3Co.vasp | -0.1529 |
| Y4Co3.vasp | -0.1935 |
| Y8Co5.vasp | -0.1644 |
| Y.vasp | 0.0162 |
| YCo2.vasp | 0.2372 |
| YCo3 (2).vasp | 0.0654 |
| YCo3.vasp | -0.1318 |
| YCo5.vasp | -0.0097 |
| YCo.vasp | 0.3796 |
| Zr (2).vasp | 0.4395 |
| Zr.vasp | 0.0058 |
