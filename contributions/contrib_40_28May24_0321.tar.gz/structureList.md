Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| Co2Zr.vasp | Zr2 Co7 | trigonal | R-3m | 37.300 |
| Co23Zr6.vasp | Zr6 Co29 | cubic | Pm-3m | 43.567 |
| Co (2).vasp | Co2 | hexagonal | P6_3/mmc | 10.988 |
| Co.vasp | Co1 | cubic | Pm-3m | 44.739 |
| CoZr2.vasp | Zr8 Co2 | tetragonal | P4/mcc | 22.143 |
| CoZr3.vasp | Zr6 Co2 | orthorhombic | Pmma | 39.656 |
| CoZr.vasp | Zr1 Co1 | cubic | Pm-3m | 16.292 |
| Y2Co7.vasp | Y4 Co14 | hexagonal | P6/mmm | 43.308 |
| Y2Co17 (2).vasp | Y4 Co34 | hexagonal | P6_3/mmc | 12.883 |
| Y2Co17.vasp | Y2 Co17 | hexagonal | P6/mmm | 39.046 |
| Y3Co.vasp | Y12 Co4 | orthorhombic | Pnma | 26.324 |
| Y4Co3.vasp | Y12 Co10 | hexagonal | P6_3/m | 21.192 |
| Y8Co5.vasp | Y32 Co20 | monoclinic | P2_1/c | 23.578 |
| Y.vasp | Y2 | hexagonal | P6_3/mmc | 33.267 |
| YCo2.vasp | Y2 Co7 | trigonal | R-3m | 41.645 |
| YCo3 (2).vasp | Y3 Co9 | trigonal | P-3m1 | 44.330 |
| YCo3.vasp | Y6 Co18 | hexagonal | P6_3/mmc | 14.775 |
| YCo5.vasp | Y1 Co5 | hexagonal | P6/mmm | 13.998 |
| YCo.vasp | Y2 Co2 | orthorhombic | Pmma | 41.530 |
| Zr (2).vasp | Zr1 | cubic | Pm-3m | 44.561 |
| Zr.vasp | Zr2 | hexagonal | P6_3/mmc | 23.220 |
