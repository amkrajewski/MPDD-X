| name | SIPFENN_NN30-OQMD [eV/atom] |
| --- | --- |
| ybco6_vol_0.vasp | -2.1219 |
| ybco6_vol_1.vasp | -2.1284 |
| ybco6_vol_2.vasp | -2.1344 |
| ybco6_vol_3.vasp | -2.14 |
| ybco6_vol_4.vasp | -2.1523 |
| ybco6_vol_5.vasp | -2.1489 |
| ybco6_vol_6.vasp | -2.1573 |
| ybco6_vol_7.vasp | -2.1597 |
| ybco6_vol_8.vasp | -2.1613 |
| ybco6_vol_9.vasp | -2.1614 |
| ybco6_vol_10.vasp | -2.1607 |
