Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| ybco6_vol_0.vasp | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 13.763 |
| ybco6_vol_1.vasp | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 13.981 |
| ybco6_vol_2.vasp | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 14.199 |
| ybco6_vol_3.vasp | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 14.418 |
| ybco6_vol_4.vasp | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 14.928 |
| ybco6_vol_5.vasp | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 14.855 |
| ybco6_vol_6.vasp | Ba8 Y4 Cu12 O24 | tetragonal | P4mm | 15.073 |
| ybco6_vol_7.vasp | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 15.292 |
| ybco6_vol_8.vasp | Ba8 Y4 Cu12 O24 | tetragonal | P4mm | 15.510 |
| ybco6_vol_9.vasp | Ba8 Y4 Cu12 O24 | tetragonal | P4mm | 15.729 |
| ybco6_vol_10.vasp | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 15.947 |
