| name | SIPFENN_NN30-OQMD [eV/atom] |
| --- | --- |
| Y2Co17.POSCAR | 0.0553 |
