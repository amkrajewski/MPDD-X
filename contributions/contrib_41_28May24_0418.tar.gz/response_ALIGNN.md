| name | ALIGNN-JARVIS Formation Energy [eV/atom] | ALIGNN-JARVIS MBJ Bandgap [eV] | ALIGNN-JARVIS Shear Modulus [GPa] | ALIGNN-JARVIS Bulk Modulus [GPa] | ALIGNN-JARVIS Exfoliation Energy [meV/atom] | ALIGNN-MP Formation Energy [eV/atom] | ALIGNN-MP PBE Bandgap [eV] |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Y2Co17.POSCAR | -0.099 | -0.0065 | 69.4816 | 156.6151 | 345.8422 | -0.088 | -0.0018 |
