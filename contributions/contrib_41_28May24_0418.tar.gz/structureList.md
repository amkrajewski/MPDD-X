Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| Y2Co17.POSCAR | Y4 Co34 | hexagonal | P6_3/mmc | 12.883 |
