| name | ALIGNN-JARVIS Formation Energy [eV/atom] | ALIGNN-JARVIS MBJ Bandgap [eV] | ALIGNN-JARVIS Shear Modulus [GPa] | ALIGNN-JARVIS Bulk Modulus [GPa] | ALIGNN-JARVIS Exfoliation Energy [meV/atom] | ALIGNN-MP Formation Energy [eV/atom] | ALIGNN-MP PBE Bandgap [eV] |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Ce3Rh2.POSCAR | -0.682 | -0.0327 | 20.9771 | 78.6622 | 437.7096 | -0.6355 | 0.0124 |
| Ce7Rh3.POSCAR | -0.5674 | -0.0521 | 22.6173 | 60.5609 | 421.9771 | -0.4782 | 0.0064 |
| Ce.POSCAR | -0.0031 | 0.0164 | 25.2531 | 36.7132 | 397.634 | 0.0896 | 0.0139 |
| CeRh2.POSCAR | -0.7471 | -0.003 | 52.0563 | 155.1705 | 456.3898 | -0.7172 | 0.0064 |
| CeRh3.POSCAR | -0.6441 | -0.004 | 67.2306 | 164.0305 | 428.9031 | -0.6446 | 0.0022 |
| CeRh.POSCAR | -0.8061 | -0.0621 | 28.4887 | 101.2792 | 412.9973 | -0.7578 | 0.0086 |
| Rh.POSCAR | -0.0076 | -0.0087 | 155.753 | 257.249 | 376.4872 | -0.0021 | 0.0102 |
