
Please note that these are *energies*, not *formation energies*.
| Name | CHGNet_0.3.0-MP Energy [eV/atom] | CHGNet_0.3.0-MP Relaxed Energy [eV/atom] |
| --- | --- | --- |
| Co2Zr.POSCAR | -5.3602 | -7.2585 |
| Co23Zr6.POSCAR | -5.4652 | -6.4066 |
| Co-HT.POSCAR | -7.0289 | -7.0289 |
| Co-RT.POSCAR | -3.7164 | -6.298 |
| CoZr2.POSCAR | -8.3335 | -8.3417 |
| CoZr3.POSCAR | -6.1114 | -7.3669 |
| CoZr.POSCAR | -8.1245 | -8.1245 |
| Y2Co7.POSCAR | -5.4913 | -5.7865 |
| Y2Co17-HT.POSCAR | -7.0993 | -7.1089 |
| Y2Co17-RT.POSCAR | -4.7075 | -5.8009 |
| Y3Co.POSCAR | -6.7833 | -6.7833 |
| Y4Co3.POSCAR | -6.926 | -6.9354 |
| Y8Co5.POSCAR | -6.8945 | -6.8977 |
| Y-RT.POSCAR | -6.4414 | -6.4414 |
| YCo2.POSCAR | -5.0753 | -6.8119 |
| YCo3-HT.POSCAR | -5.5594 | -5.9202 |
| YCo3-RT.POSCAR | -7.0984 | -7.1013 |
| YCo5.POSCAR | -7.1008 | -7.102 |
| YCo.POSCAR | -5.2179 | -5.9473 |
| Zr-HT.POSCAR | -6.452 | -7.8966 |
| Zr-RT.POSCAR | -8.5082 | -8.509 |
