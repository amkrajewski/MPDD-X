Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| Co2Zr.POSCAR | Zr2 Co7 | trigonal | R-3m | 37.300 |
| Co23Zr6.POSCAR | Zr6 Co29 | cubic | Pm-3m | 43.567 |
| Co-HT.POSCAR | Co2 | hexagonal | P6_3/mmc | 10.988 |
| Co-RT.POSCAR | Co1 | cubic | Pm-3m | 44.739 |
| CoZr2.POSCAR | Zr8 Co2 | tetragonal | P4/mcc | 22.143 |
| CoZr3.POSCAR | Zr6 Co2 | orthorhombic | Pmma | 39.656 |
| CoZr.POSCAR | Zr1 Co1 | cubic | Pm-3m | 16.292 |
| Y2Co7.POSCAR | Y4 Co14 | hexagonal | P6/mmm | 43.308 |
| Y2Co17-HT.POSCAR | Y4 Co34 | hexagonal | P6_3/mmc | 12.883 |
| Y2Co17-RT.POSCAR | Y2 Co17 | hexagonal | P6/mmm | 39.046 |
| Y3Co.POSCAR | Y12 Co4 | orthorhombic | Pnma | 26.324 |
| Y4Co3.POSCAR | Y12 Co10 | hexagonal | P6_3/m | 21.192 |
| Y8Co5.POSCAR | Y32 Co20 | monoclinic | P2_1/c | 23.578 |
| Y-RT.POSCAR | Y2 | hexagonal | P6_3/mmc | 33.267 |
| YCo2.POSCAR | Y2 Co7 | trigonal | R-3m | 41.645 |
| YCo3-HT.POSCAR | Y3 Co9 | trigonal | P-3m1 | 44.330 |
| YCo3-RT.POSCAR | Y6 Co18 | hexagonal | P6_3/mmc | 14.775 |
| YCo5.POSCAR | Y1 Co5 | hexagonal | P6/mmm | 13.998 |
| YCo.POSCAR | Y2 Co2 | orthorhombic | Pmma | 41.530 |
| Zr-HT.POSCAR | Zr1 | cubic | Pm-3m | 44.561 |
| Zr-RT.POSCAR | Zr2 | hexagonal | P6_3/mmc | 23.220 |
