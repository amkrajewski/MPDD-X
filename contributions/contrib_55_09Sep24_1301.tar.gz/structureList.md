Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| POSCAR.VASP | Li8 Zn8 | cubic | Fd-3m | 14.165 |
