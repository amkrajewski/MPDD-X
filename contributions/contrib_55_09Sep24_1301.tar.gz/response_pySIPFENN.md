| name | SIPFENN_NN30-OQMD [eV/atom] |
| --- | --- |
| POSCAR.VASP | -0.1876 |
