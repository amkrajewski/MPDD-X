| name | ALIGNN-JARVIS Formation Energy [eV/atom] | ALIGNN-JARVIS MBJ Bandgap [eV] | ALIGNN-JARVIS Shear Modulus [GPa] | ALIGNN-JARVIS Bulk Modulus [GPa] | ALIGNN-JARVIS Exfoliation Energy [meV/atom] | ALIGNN-MP Formation Energy [eV/atom] | ALIGNN-MP PBE Bandgap [eV] |
| --- | --- | --- | --- | --- | --- | --- | --- |
| POSCAR.VASP | -0.2516 | -0.0304 | 31.4424 | 42.5166 | 526.1657 | -0.2194 | 0.0143 |
