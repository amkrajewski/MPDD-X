Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| Eu2Rh.POSCAR | Eu16 Rh8 | cubic | Fd-3m | 26.052 |
| Eu3Rh.POSCAR | Eu12 Rh4 | orthorhombic | Pnma | 30.858 |
| Eu5Rh2.POSCAR | Eu20 Rh8 | monoclinic | C2/c | 31.115 |
| Eu-cub.POSCAR | Eu2 | cubic | Im-3m | 36.022 |
| EuRh2.POSCAR | Eu8 Rh16 | cubic | Fd-3m | 18.889 |
| Eu_Hexag.POSCAR | Eu2 | hexagonal | P6_3/mmc | 38.179 |
| Rh.POSCAR | Rh4 | cubic | Fm-3m | 14.490 |
