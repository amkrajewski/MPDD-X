| name | ALIGNN-JARVIS Formation Energy [eV/atom] | ALIGNN-JARVIS MBJ Bandgap [eV] | ALIGNN-JARVIS Shear Modulus [GPa] | ALIGNN-JARVIS Bulk Modulus [GPa] | ALIGNN-JARVIS Exfoliation Energy [meV/atom] | ALIGNN-MP Formation Energy [eV/atom] | ALIGNN-MP PBE Bandgap [eV] |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Eu2Rh.POSCAR | 0.4257 | -0.0216 | 27.0466 | 95.1086 | 489.131 | 0.0887 | 0.0106 |
| Eu3Rh.POSCAR | -0.4881 | 0.0041 | 22.6663 | 48.939 | 481.842 | -0.3199 | 0.0116 |
| Eu5Rh2.POSCAR | -0.4869 | -0.0045 | 22.9491 | 54.3822 | 477.0386 | -0.3186 | 0.0067 |
| Eu-cub.POSCAR | 0.0559 | -0.001 | 11.8909 | 35.1605 | 527.8611 | 0.0993 | 0.0214 |
| EuRh2.POSCAR | -0.7271 | -0.0228 | 60.3726 | 159.6115 | 484.2272 | -0.4711 | 0.0117 |
| Eu_Hexag.POSCAR | 0.0012 | 0.0082 | 14.9345 | 34.3951 | 525.8373 | 0.0383 | 0.0155 |
| Rh.POSCAR | -0.0055 | -0.0061 | 155.7247 | 257.824 | 375.0375 | -0.0012 | 0.0089 |
