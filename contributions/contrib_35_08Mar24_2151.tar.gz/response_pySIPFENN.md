| name | SIPFENN_NN30-OQMD [eV/atom] |
| --- | --- |
| Eu2Rh.POSCAR | -0.4749 |
| Eu3Rh.POSCAR | -0.4481 |
| Eu5Rh2.POSCAR | -0.4841 |
| Eu-cub.POSCAR | 0.0136 |
| EuRh2.POSCAR | -0.5485 |
| Eu_Hexag.POSCAR | 0.0284 |
| Rh.POSCAR | 0.0127 |
