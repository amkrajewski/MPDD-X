
Please note that these are *energies*, not *formation energies*.
| Name | CHGNet_0.3.0-MP Energy [eV/atom] | CHGNet_0.3.0-MP Relaxed Energy [eV/atom] |
| --- | --- | --- |
| Eu2Rh.POSCAR | -8.6259 | -8.7071 |
| Eu3Rh.POSCAR | -9.8565 | -9.8565 |
| Eu5Rh2.POSCAR | -9.7606 | -9.7853 |
| Eu-cub.POSCAR | -10.1892 | -10.2562 |
| EuRh2.POSCAR | -8.7706 | -8.7706 |
| Eu_Hexag.POSCAR | -10.2208 | -10.2513 |
| Rh.POSCAR | -7.2976 | -7.3003 |
