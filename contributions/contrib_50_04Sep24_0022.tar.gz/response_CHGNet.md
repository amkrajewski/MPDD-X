
Please note that these are *energies*, not *formation energies*.
| Name | CHGNet_0.3.0-MP Energy [eV/atom] | CHGNet_0.3.0-MP Relaxed Energy [eV/atom] |
| --- | --- | --- |
| CePt2.POSCAR | -3.145 | -3.145 |
| CePt3.POSCAR | -7.0238 | -7.025 |
| CePt5.POSCAR | -6.7265 | -6.7305 |
| Sc2Pt.POSCAR | -7.2182 | -7.2216 |
| Sc57Pt13.POSCAR | -6.8154 | -6.8154 |
| ScPt3.POSCAR | -7.1516 | -7.1587 |
| ScPt.POSCAR | -7.4522 | -7.4529 |
| V3Pt.POSCAR | -8.7236 | -8.7248 |
| VPt2.POSCAR | -7.5431 | -7.5501 |
| VPt3.POSCAR | -7.2512 | -7.2516 |
| VPt8.POSCAR | -6.62 | -6.6267 |
| VPt.POSCAR | -8.084 | -8.0878 |
| Y2Pt.POSCAR | -7.2602 | -7.2608 |
| Y3Pt.POSCAR | -7.0751 | -7.0751 |
| YPt2.POSCAR | -7.3244 | -7.3281 |
| YPt3.POSCAR | -7.1251 | -7.1286 |
| YPt.POSCAR | -7.4931 | -7.4953 |
