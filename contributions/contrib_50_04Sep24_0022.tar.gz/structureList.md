Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| CePt2.POSCAR | Pt16 Xe8 | cubic | Fd-3m | 19.483 |
| CePt3.POSCAR | Ce1 Pt3 | cubic | Pm-3m | 17.857 |
| CePt5.POSCAR | Ce1 Pt5 | hexagonal | P6/mmm | 18.375 |
| Sc2Pt.POSCAR | Sc8 Pt4 | orthorhombic | Pnma | 20.406 |
| Sc57Pt13.POSCAR | Sc114 Pt26 | cubic | Pm-3 | 21.784 |
| ScPt3.POSCAR | Sc1 Pt3 | cubic | Pm-3m | 15.812 |
| ScPt.POSCAR | Sc1 Pt1 | cubic | Pm-3m | 17.796 |
| V3Pt.POSCAR | V6 Pt2 | cubic | Pm-3n | 13.721 |
| VPt2.POSCAR | V2 Pt4 | orthorhombic | Immm | 14.447 |
| VPt3.POSCAR | V1 Pt3 | cubic | Pm-3m | 14.843 |
| VPt8.POSCAR | V2 Pt16 | tetragonal | I4/mmm | 15.006 |
| VPt.POSCAR | V1 Pt1 | tetragonal | P4/mmm | 14.045 |
| Y2Pt.POSCAR | Y8 Pt4 | orthorhombic | Pnma | 25.192 |
| Y3Pt.POSCAR | Y12 Pt4 | orthorhombic | Pnma | 28.047 |
| YPt2.POSCAR | Y8 Pt16 | cubic | Fd-3m | 18.660 |
| YPt3.POSCAR | Y1 Pt3 | cubic | Pm-3m | 17.235 |
| YPt.POSCAR | Y4 Pt4 | orthorhombic | Pnma | 22.073 |
