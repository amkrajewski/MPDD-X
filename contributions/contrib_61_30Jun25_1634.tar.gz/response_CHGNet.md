
Please note that these are *energies*, not *formation energies*.
| Name | CHGNet_0.3.0-MP Energy [eV/atom] | CHGNet_0.3.0-MP Relaxed Energy [eV/atom] |
| --- | --- | --- |
| Nd2Tl.POSCAR | -4.2326 | -4.2326 |
| Nd3Tl5.POSCAR | -3.6197 | -3.625 |
| Nd3Tl.POSCAR | -4.3334 | -4.3334 |
| NdTl3.POSCAR | -3.2215 | -3.2239 |
| NdTl.POSCAR | -3.9772 | -3.9772 |
