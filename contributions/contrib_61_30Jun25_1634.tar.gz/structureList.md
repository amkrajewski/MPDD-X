Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| Nd2Tl.POSCAR | Nd4 Tl2 | hexagonal | P6_3/mmc | 30.939 |
| Nd3Tl5.POSCAR | Nd12 Tl20 | orthorhombic | Cmcm | 28.545 |
| Nd3Tl.POSCAR | Nd3 Tl1 | cubic | Pm-3m | 31.040 |
| NdTl3.POSCAR | Nd1 Tl3 | cubic | Pm-3m | 27.564 |
| NdTl.POSCAR | Nd1 Tl1 | cubic | Pm-3m | 29.355 |
