| name | ALIGNN-JARVIS Formation Energy [eV/atom] | ALIGNN-JARVIS MBJ Bandgap [eV] | ALIGNN-JARVIS Shear Modulus [GPa] | ALIGNN-JARVIS Bulk Modulus [GPa] | ALIGNN-JARVIS Exfoliation Energy [meV/atom] | ALIGNN-MP Formation Energy [eV/atom] | ALIGNN-MP PBE Bandgap [eV] | ALIGNN-Alexandria Bandgap [eV] | ALIGNN-Alexandria Formation Energy [eV/atom] | ALIGNN-Alexandria Volume Per Atom [A^3] |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Nd2Tl.POSCAR | -0.2804 | 0.0164 | 17.6478 | 49.8636 | 345.5179 | -0.275 | 0.0019 | 0.001 | -0.2641 | 30.9661 |
| Nd3Tl5.POSCAR | -0.4136 | 0.0004 | 22.5223 | 53.1608 | 231.7609 | -0.3667 | 0.0124 | 0.0011 | -0.351 | 28.5575 |
| Nd3Tl.POSCAR | -0.2303 | -0.027 | 20.3111 | 47.4453 | 368.8638 | -0.213 | -0.0029 | 0.0014 | -0.1947 | 31.0664 |
| NdTl3.POSCAR | -0.3179 | 0.0411 | 19.1874 | 48.7893 | 229.1991 | -0.2882 | 0.0126 | 0.0021 | -0.3009 | 27.5801 |
| NdTl.POSCAR | -0.4041 | -0.0232 | 18.8468 | 49.143 | 235.104 | -0.3875 | 0.0089 | -0.0001 | -0.3799 | 29.3873 |
