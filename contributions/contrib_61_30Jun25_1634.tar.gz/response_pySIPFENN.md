| name | SIPFENN_NN30-OQMD [eV/atom] |
| --- | --- |
| Nd2Tl.POSCAR | -0.2727 |
| Nd3Tl5.POSCAR | -0.338 |
| Nd3Tl.POSCAR | -0.2097 |
| NdTl3.POSCAR | -0.25 |
| NdTl.POSCAR | -0.3814 |
