Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| Eu2Rh.vasp | Eu16 Rh8 | cubic | Fd-3m | 26.052 |
| Eu3Rh.vasp | Eu12 Rh4 | orthorhombic | Pnma | 30.858 |
| Eu5Rh2.vasp | Eu20 Rh8 | monoclinic | C2/c | 31.115 |
| Eu-cub.vasp | Eu2 | cubic | Im-3m | 36.022 |
| EuRh2.vasp | Eu8 Rh16 | cubic | Fd-3m | 18.889 |
| Eu_Hexag.vasp | Eu2 | hexagonal | P6_3/mmc | 38.179 |
| Rh.vasp | Rh4 | cubic | Fm-3m | 14.490 |
