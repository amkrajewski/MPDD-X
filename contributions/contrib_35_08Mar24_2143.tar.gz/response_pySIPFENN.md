| name | SIPFENN_NN30-OQMD [eV/atom] |
| --- | --- |
| Eu2Rh.vasp | -0.4749 |
| Eu3Rh.vasp | -0.4481 |
| Eu5Rh2.vasp | -0.4841 |
| Eu-cub.vasp | 0.0136 |
| EuRh2.vasp | -0.5485 |
| Eu_Hexag.vasp | 0.0284 |
| Rh.vasp | 0.0127 |
