| name | ALIGNN-JARVIS Formation Energy [eV/atom] | ALIGNN-JARVIS MBJ Bandgap [eV] | ALIGNN-JARVIS Shear Modulus [GPa] | ALIGNN-JARVIS Bulk Modulus [GPa] | ALIGNN-JARVIS Exfoliation Energy [meV/atom] | ALIGNN-MP Formation Energy [eV/atom] | ALIGNN-MP PBE Bandgap [eV] |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ybco6_vol_0.POSCAR | -2.1051 | 0.1154 | 46.3395 | 102.5103 | 133.131 | -2.234 | 0.0059 |
| ybco6_vol_1.POSCAR | -2.1074 | 0.1167 | 44.9711 | 101.6913 | 135.7478 | -2.2391 | 0.0206 |
| ybco6_vol_2.POSCAR | -2.1116 | 0.1705 | 43.5024 | 99.1959 | 136.1978 | -2.2448 | 0.0014 |
| ybco6_vol_3.POSCAR | -2.1134 | 0.1703 | 42.9828 | 97.3296 | 135.7299 | -2.2458 | 0.0147 |
| ybco6_vol_4.POSCAR | -2.1183 | 0.1666 | 38.1682 | 94.7947 | 127.1666 | -2.2417 | 0.0142 |
| ybco6_vol_5.POSCAR | -2.114 | 0.1577 | 39.2721 | 95.7604 | 131.9534 | -2.2446 | 0.0274 |
| ybco6_vol_6.POSCAR | -2.1196 | 0.1355 | 37.6345 | 94.3189 | 126.4777 | -2.2419 | -0.0006 |
| ybco6_vol_7.POSCAR | -2.1217 | 0.1029 | 36.9457 | 93.4488 | 124.8498 | -2.2417 | 0.0115 |
| ybco6_vol_8.POSCAR | -2.1292 | 0.1289 | 36.6836 | 92.5109 | 122.0164 | -2.2381 | 0.0171 |
| ybco6_vol_9.POSCAR | -2.1309 | 0.148 | 36.456 | 92.2103 | 119.1404 | -2.2374 | 0.0811 |
| ybco6_vol_10.POSCAR | -2.1132 | 0.1311 | 33.8084 | 91.3065 | 120.1416 | -2.2155 | 0.0692 |
