
Please note that these are *energies*, not *formation energies*.
| Name | CHGNet_0.3.0-MP Energy [eV/atom] | CHGNet_0.3.0-MP Relaxed Energy [eV/atom] |
| --- | --- | --- |
| ybco6_vol_0.POSCAR | -6.5286 | -6.5713 |
| ybco6_vol_1.POSCAR | -6.5422 | -6.5717 |
| ybco6_vol_2.POSCAR | -6.5527 | -6.5726 |
| ybco6_vol_3.POSCAR | -6.561 | -6.5725 |
| ybco6_vol_4.POSCAR | -6.5722 | -6.5729 |
| ybco6_vol_5.POSCAR | -6.5709 | -6.5719 |
| ybco6_vol_6.POSCAR | -6.5738 | -6.5738 |
| ybco6_vol_7.POSCAR | -6.5751 | -6.5751 |
| ybco6_vol_8.POSCAR | -6.5748 | -6.5748 |
| ybco6_vol_9.POSCAR | -6.5729 | -6.5729 |
| ybco6_vol_10.POSCAR | -6.5698 | -6.5737 |
