Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| ybco6_vol_0.POSCAR | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 13.763 |
| ybco6_vol_1.POSCAR | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 13.981 |
| ybco6_vol_2.POSCAR | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 14.199 |
| ybco6_vol_3.POSCAR | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 14.418 |
| ybco6_vol_4.POSCAR | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 14.928 |
| ybco6_vol_5.POSCAR | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 14.855 |
| ybco6_vol_6.POSCAR | Ba8 Y4 Cu12 O24 | tetragonal | P4mm | 15.073 |
| ybco6_vol_7.POSCAR | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 15.292 |
| ybco6_vol_8.POSCAR | Ba8 Y4 Cu12 O24 | tetragonal | P4mm | 15.510 |
| ybco6_vol_9.POSCAR | Ba8 Y4 Cu12 O24 | tetragonal | P4mm | 15.729 |
| ybco6_vol_10.POSCAR | Ba8 Y4 Cu12 O24 | tetragonal | P4/mmm | 15.947 |
