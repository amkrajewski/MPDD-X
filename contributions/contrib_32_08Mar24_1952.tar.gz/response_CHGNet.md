
Please note that these are *energies*, not *formation energies*.
| Name | CHGNet_0.3.0-MP Energy [eV/atom] | CHGNet_0.3.0-MP Relaxed Energy [eV/atom] |
| --- | --- | --- |
| Ce3Rh2.POSCAR | -7.1149 | -7.1149 |
| Ce7Rh3.POSCAR | -6.7931 | -6.7931 |
| Ce.POSCAR | -5.8037 | -5.8609 |
| CeRh2.POSCAR | -7.5996 | -7.5996 |
| CeRh3.POSCAR | -7.6745 | -7.6745 |
| CeRh.POSCAR | -7.3926 | -7.3926 |
| Rh.POSCAR | -7.2977 | -7.3003 |
