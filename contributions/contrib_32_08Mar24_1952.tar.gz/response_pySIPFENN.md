| name | SIPFENN_NN30-OQMD [eV/atom] |
| --- | --- |
| Ce3Rh2.POSCAR | -0.5413 |
| Ce7Rh3.POSCAR | -0.4546 |
| Ce.POSCAR | 0.0123 |
| CeRh2.POSCAR | -0.4351 |
| CeRh3.POSCAR | -0.2374 |
| CeRh.POSCAR | -0.6209 |
| Rh.POSCAR | 0.0127 |
