Structure Record:
| Name | Formula | Crytal Family | Space Group | Volume per Atom |
| --- | --- | --- | --- | --- |
| 0-Cr8Fe18Ni4.POSCAR | Cr8 Fe18 Ni4 | tetragonal | P4_2/mnm | 10.904 |
| 1-Cr16Fe8Ni6.POSCAR | Cr16 Fe8 Ni6 | tetragonal | P4_2/mnm | 10.644 |
| 2-Fe8Ni22.POSCAR | Fe8 Ni22 | tetragonal | P4_2/mnm | 10.659 |
| 3-Cr18Fe12.POSCAR | Cr18 Fe12 | tetragonal | P4_2/mnm | 10.703 |
| 4-Fe30.POSCAR | Fe30 | tetragonal | P4_2/mnm | 11.101 |
| 5-Cr22Fe8.POSCAR | Cr22 Fe8 | tetragonal | P4_2/mnm | 10.734 |
| 6-Fe2Ni28.POSCAR | Fe2 Ni28 | tetragonal | P4_2/mnm | 10.330 |
| 7-Cr18Fe12.POSCAR | Cr18 Fe12 | tetragonal | P4_2/mnm | 10.379 |
| 8-Cr2Fe16Ni12.POSCAR | Cr2 Fe16 Ni12 | tetragonal | P4_2/mnm | 10.874 |
| 9-Pb8O12.POSCAR | Pb8 O12 | orthorhombic | Pnma | 15.141 |
| 10-Ce4Ti4O12.POSCAR | Ce4 Ti4 O12 | orthorhombic | Pnma | 14.240 |
| 11-Fe10Ni20.POSCAR | Fe10 Ni20 | tetragonal | P4_2/mnm | 10.591 |
| 12-Gd4Cr4O12.POSCAR | Gd4 Cr4 O12 | orthorhombic | Pnma | 11.301 |
| 13-Fe16Ni14.POSCAR | Fe16 Ni14 | tetragonal | P4_2/mnm | 10.748 |
| 14-Fe24Ni6.POSCAR | Fe24 Ni6 | tetragonal | P4_2/mnm | 10.892 |
| 15-Ta4Tl4O12.POSCAR | Ta4 Tl4 O12 | orthorhombic | Imma | 13.224 |
| 16-Fe18Ni12.POSCAR | Fe18 Ni12 | tetragonal | P4_2/mnm | 10.850 |
| 17-Pr4Ga4O12.POSCAR | Pr4 Ga4 O12 | orthorhombic | Pnma | 13.882 |
| 18-Fe28Ni2.POSCAR | Fe28 Ni2 | tetragonal | P4_2/mnm | 11.541 |
| 19-Fe4Ni26.POSCAR | Fe4 Ni26 | tetragonal | P4_2/mnm | 10.456 |
| 20-Fe8Ni22.POSCAR | Fe8 Ni22 | tetragonal | P4_2/mnm | 10.821 |
| 21-Fe10Ni20.POSCAR | Fe10 Ni20 | tetragonal | P4_2/mnm | 10.628 |
| 22-Fe10Ni20.POSCAR | Fe10 Ni20 | tetragonal | P4_2/mnm | 11.144 |
| 23-Fe12Ni18.POSCAR | Fe12 Ni18 | tetragonal | P4_2/mnm | 10.729 |
| 24-Fe16Ni14.POSCAR | Fe16 Ni14 | tetragonal | P4_2/mnm | 10.798 |
| 25-Fe12Ni18.POSCAR | Fe12 Ni18 | tetragonal | P4_2/mnm | 10.934 |
| 26-Fe8Ni22.POSCAR | Fe8 Ni22 | tetragonal | P4_2/mnm | 10.540 |
| 27-Cr28Fe2.POSCAR | Cr28 Fe2 | tetragonal | P4_2/mnm | 11.150 |
| 28-Fe26Ni4.POSCAR | Fe26 Ni4 | tetragonal | P4_2/mnm | 10.993 |
| 29-Fe12Ni18.POSCAR | Fe12 Ni18 | tetragonal | P4_2/mnm | 10.771 |
| 30-Cr26Fe4.POSCAR | Cr26 Fe4 | tetragonal | P4_2/mnm | 10.804 |
| 31-Li24Al4Ni32.POSCAR | Li24 Al4 Ni32 | cubic | Fm-3m | 3.600 |
